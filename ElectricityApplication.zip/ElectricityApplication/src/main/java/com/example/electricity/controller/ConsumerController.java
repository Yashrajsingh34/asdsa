package com.example.electricity.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.example.electricity.entity.Consumer;
import com.example.electricity.service.ConsumerService;

import jakarta.validation.Valid;

@Controller
public class ConsumerController {

    @Autowired
    private ConsumerService service;

    // Home Page
    @GetMapping("/")
    public String home(Model model) {

        model.addAttribute("consumers", service.getAllConsumers());

        return "index";
    }

    // Add Consumer Page
    @GetMapping("/add")
    public String addConsumer(Model model) {

        model.addAttribute("consumer", new Consumer());

        return "addConsumer";
    }

    // Save Consumer
    @PostMapping("/save")
    public String saveConsumer(@Valid @ModelAttribute("consumer") Consumer consumer,
                               BindingResult result) {

        if (result.hasErrors()) {
            return "addConsumer";
        }

        service.saveConsumer(consumer);

        return "redirect:/";
    }

    // Edit Consumer
    @GetMapping("/edit/{id}")
    public String editConsumer(@PathVariable Long id, Model model) {

        Consumer consumer = service.getConsumerById(id);

        model.addAttribute("consumer", consumer);

        return "updateConsumer";
    }

    // Update Consumer
    @PostMapping("/update")
    public String updateConsumer(@Valid @ModelAttribute("consumer") Consumer consumer,
                                 BindingResult result) {

        if (result.hasErrors()) {
            return "updateConsumer";
        }

        service.saveConsumer(consumer);

        return "redirect:/";
    }

    // Delete Consumer
    @GetMapping("/delete/{id}")
    public String deleteConsumer(@PathVariable Long id) {

        service.deleteConsumer(id);

        return "redirect:/";
    }

    // Search Consumer
    @GetMapping("/search")
    public String searchConsumer(@RequestParam("keyword") String keyword,
                                 @RequestParam("type") String type,
                                 Model model) {

        List<Consumer> consumers;

        if (type.equals("name")) {

            consumers = service.searchByName(keyword);

        } else {

            consumers = service.searchByMeter(keyword);

        }

        model.addAttribute("consumers", consumers);

        return "index";
    }

    // Sorting
    @GetMapping("/sort")
    public String sortConsumer(@RequestParam("field") String field,
                               @RequestParam("order") String order,
                               Model model) {

        List<Consumer> consumers = null;

        if (field.equals("name")) {

            if (order.equals("asc"))
                consumers = service.sortByNameAsc();
            else
                consumers = service.sortByNameDesc();

        }

        else if (field.equals("bill")) {

            if (order.equals("asc"))
                consumers = service.sortByBillAsc();
            else
                consumers = service.sortByBillDesc();

        }

        else if (field.equals("units")) {

            if (order.equals("asc"))
                consumers = service.sortByUnitsAsc();
            else
                consumers = service.sortByUnitsDesc();

        }

        model.addAttribute("consumers", consumers);

        return "index";
    }

}