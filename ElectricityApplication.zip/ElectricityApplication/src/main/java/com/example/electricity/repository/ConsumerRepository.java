package com.example.electricity.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.electricity.entity.Consumer;

public interface ConsumerRepository extends JpaRepository<Consumer, Long> {

    // Search by Consumer Name
    List<Consumer> findByConsumerNameContainingIgnoreCase(String consumerName);

    // Search by Meter Number
    List<Consumer> findByMeterNumberContainingIgnoreCase(String meterNumber);

    // Sorting
    List<Consumer> findAllByOrderByConsumerNameAsc();

    List<Consumer> findAllByOrderByConsumerNameDesc();

    List<Consumer> findAllByOrderByBillAmountAsc();

    List<Consumer> findAllByOrderByBillAmountDesc();

    List<Consumer> findAllByOrderByUnitsConsumedAsc();

    List<Consumer> findAllByOrderByUnitsConsumedDesc();

}