package com.example.electricity.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "consumers")
public class Consumer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Consumer name is required")
    private String consumerName;

    @NotBlank(message = "Meter number is required")
    private String meterNumber;

    @NotBlank(message = "Address is required")
    private String address;

    @Pattern(
            regexp = "^[0-9]{10}$",
            message = "Phone number must contain exactly 10 digits"
    )
    private String phoneNumber;

    @Email(message = "Invalid email")
    private String email;

    @NotBlank(message = "Connection type is required")
    private String connectionType;

    @Min(value = 0, message = "Units cannot be negative")
    private int unitsConsumed;

    private double billAmount;

    @NotBlank(message = "Payment status is required")
    private String paymentStatus;

    public Consumer() {
    }

    public Consumer(Long id,
                    String consumerName,
                    String meterNumber,
                    String address,
                    String phoneNumber,
                    String email,
                    String connectionType,
                    int unitsConsumed,
                    double billAmount,
                    String paymentStatus) {

        this.id = id;
        this.consumerName = consumerName;
        this.meterNumber = meterNumber;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.connectionType = connectionType;
        this.unitsConsumed = unitsConsumed;
        this.billAmount = billAmount;
        this.paymentStatus = paymentStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id=id;
    }

    public String getConsumerName() {
        return consumerName;
    }

    public void setConsumerName(String consumerName) {
        this.consumerName=consumerName;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber=meterNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address=address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber=phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email=email;
    }

    public String getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(String connectionType) {
        this.connectionType=connectionType;
    }

    public int getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(int unitsConsumed) {
        this.unitsConsumed=unitsConsumed;
    }

    public double getBillAmount() {
        return billAmount;
    }

    public void setBillAmount(double billAmount) {
        this.billAmount=billAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus=paymentStatus;
    }

}