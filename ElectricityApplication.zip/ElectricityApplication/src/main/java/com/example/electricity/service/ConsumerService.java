package com.example.electricity.service;

import java.util.List;

import com.example.electricity.entity.Consumer;

public interface ConsumerService {

    List<Consumer> getAllConsumers();

    void saveConsumer(Consumer consumer);

    Consumer getConsumerById(Long id);

    void deleteConsumer(Long id);

    List<Consumer> searchByName(String name);

    List<Consumer> searchByMeter(String meterNo);

    List<Consumer> sortByNameAsc();

    List<Consumer> sortByNameDesc();

    List<Consumer> sortByBillAsc();

    List<Consumer> sortByBillDesc();

    List<Consumer> sortByUnitsAsc();

    List<Consumer> sortByUnitsDesc();

}