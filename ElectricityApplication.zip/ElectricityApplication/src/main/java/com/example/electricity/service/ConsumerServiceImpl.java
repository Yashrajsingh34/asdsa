package com.example.electricity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.electricity.entity.Consumer;
import com.example.electricity.repository.ConsumerRepository;

@Service
public class ConsumerServiceImpl implements ConsumerService {

    @Autowired
    private ConsumerRepository repository;

    @Override
    public List<Consumer> getAllConsumers() {
        return repository.findAll();
    }

    @Override
    public void saveConsumer(Consumer consumer) {

        double bill = calculateBill(
                consumer.getUnitsConsumed(),
                consumer.getConnectionType());

        consumer.setBillAmount(bill);

        repository.save(consumer);
    }

    @Override
    public Consumer getConsumerById(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void deleteConsumer(Long id) {
        repository.deleteById(id);
    }

    @Override
    public List<Consumer> searchByName(String name) {
        return repository.findByConsumerNameContainingIgnoreCase(name);
    }

    @Override
    public List<Consumer> searchByMeter(String meterNo) {
        return repository.findByMeterNumberContainingIgnoreCase(meterNo);
    }

    @Override
    public List<Consumer> sortByNameAsc() {
        return repository.findAllByOrderByConsumerNameAsc();
    }

    @Override
    public List<Consumer> sortByNameDesc() {
        return repository.findAllByOrderByConsumerNameDesc();
    }

    @Override
    public List<Consumer> sortByBillAsc() {
        return repository.findAllByOrderByBillAmountAsc();
    }

    @Override
    public List<Consumer> sortByBillDesc() {
        return repository.findAllByOrderByBillAmountDesc();
    }

    @Override
    public List<Consumer> sortByUnitsAsc() {
        return repository.findAllByOrderByUnitsConsumedAsc();
    }

    @Override
    public List<Consumer> sortByUnitsDesc() {
        return repository.findAllByOrderByUnitsConsumedDesc();
    }

    // -------------------------------
    // BILL CALCULATION
    // -------------------------------

    private double calculateBill(int units, String connectionType) {

        double bill = 0;

        if (connectionType.equalsIgnoreCase("Domestic")) {

            if (units <= 100) {

                bill = units * 2;

            } else if (units <= 300) {

                bill = (100 * 2) + ((units - 100) * 4);

            } else {

                bill = (100 * 2)
                        + (200 * 4)
                        + ((units - 300) * 6);

            }

        } else {

            if (units <= 100) {

                bill = units * 5;

            } else if (units <= 300) {

                bill = (100 * 5)
                        + ((units - 100) * 7);

            } else {

                bill = (100 * 5)
                        + (200 * 7)
                        + ((units - 300) * 10);

            }

        }

        return bill;

    }

}