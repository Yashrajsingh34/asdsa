import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.dao.BookDAO;

@WebServlet("/ViewBookServlet")
public class ViewBookServlet
extends HttpServlet {

 protected void doGet(
  HttpServletRequest request,
  HttpServletResponse response)
  throws ServletException, IOException {

  BookDAO dao =
   new BookDAO();

  request.setAttribute(
   "books",
   dao.getAllBooks());

  RequestDispatcher rd =
   request.getRequestDispatcher(
    "viewBooks.jsp");

  rd.forward(request,response);
 }
}