package com.library.servlet;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.library.dao.BookDAO;
import com.library.model.Book;

@WebServlet("/UpdateBookServlet")
public class UpdateBookServlet extends HttpServlet {

    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        Book b = new Book();

        b.setBid(
                Integer.parseInt(
                        request.getParameter("bid")));

        b.setBname(
                request.getParameter("bname"));

        b.setAuthor(
                request.getParameter("author"));

        b.setPrice(
                Double.parseDouble(
                        request.getParameter("price")));

        BookDAO dao =
                new BookDAO();

        dao.updateBook(b);

        response.sendRedirect(
                "ViewBookServlet");
    }
}