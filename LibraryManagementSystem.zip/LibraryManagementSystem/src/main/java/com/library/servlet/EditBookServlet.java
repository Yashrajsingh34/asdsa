package com.library.servlet;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.library.dao.BookDAO;
import com.library.model.Book;

@WebServlet("/EditBookServlet")
public class EditBookServlet extends HttpServlet {

    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int bid =
                Integer.parseInt(
                        request.getParameter("bid"));

        BookDAO dao = new BookDAO();

        Book book =
                dao.getBookById(bid);

        request.setAttribute(
                "book",
                book);

        RequestDispatcher rd =
                request.getRequestDispatcher(
                        "editBook.jsp");

        rd.forward(request, response);
    }
}