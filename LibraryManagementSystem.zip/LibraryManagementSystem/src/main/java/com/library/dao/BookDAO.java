package com.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.library.model.Book;
import com.library.util.DBConnection;

public class BookDAO {

    // Add Book
    public boolean addBook(Book b) {

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(
                            "insert into book values(?,?,?,?)");

            ps.setInt(1, b.getBid());
            ps.setString(2, b.getBname());
            ps.setString(3, b.getAuthor());
            ps.setDouble(4, b.getPrice());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // View All Books
    public List<Book> getAllBooks() {

        List<Book> list = new ArrayList<>();

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(
                            "select * from book");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Book b = new Book();

                b.setBid(rs.getInt("bid"));
                b.setBname(rs.getString("bname"));
                b.setAuthor(rs.getString("author"));
                b.setPrice(rs.getDouble("price"));

                list.add(b);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // Get Book By ID
    public Book getBookById(int id) {

        Book b = null;

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(
                            "select * from book where bid=?");

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                b = new Book();

                b.setBid(rs.getInt("bid"));
                b.setBname(rs.getString("bname"));
                b.setAuthor(rs.getString("author"));
                b.setPrice(rs.getDouble("price"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return b;
    }

    // Update Book
    public boolean updateBook(Book b) {

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(
                            "update book set bname=?, author=?, price=? where bid=?");

            ps.setString(1, b.getBname());
            ps.setString(2, b.getAuthor());
            ps.setDouble(3, b.getPrice());
            ps.setInt(4, b.getBid());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}