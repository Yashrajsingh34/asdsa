package com.library.dao;

import java.sql.*;

import com.library.util.DBConnection;

public class LoginDAO {

    public boolean validate(
            String username,
            String password) {

        try {

            Connection con =
                    DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(
                            "select * from login where username=? and password=?");

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs =
                    ps.executeQuery();

            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}