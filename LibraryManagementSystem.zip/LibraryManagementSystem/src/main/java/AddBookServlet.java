import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.dao.BookDAO;
import com.library.model.Book;

@WebServlet("/AddBookServlet")
public class AddBookServlet
extends HttpServlet {

 protected void doPost(
  HttpServletRequest request,
  HttpServletResponse response)
  throws IOException {

  Book b = new Book();

  b.setBid(
   Integer.parseInt(
    request.getParameter("bid")));

  b.setBname(
   request.getParameter("bname"));

  b.setAuthor(
   request.getParameter("author"));

  b.setPrice(
   Double.parseDouble(
    request.getParameter("price")));

  BookDAO dao =
   new BookDAO();

  dao.addBook(b);

  response.sendRedirect(
   "dashboard.jsp");
 }
}