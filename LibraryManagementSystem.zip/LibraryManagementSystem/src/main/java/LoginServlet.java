import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.library.dao.LoginDAO;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String username =
                request.getParameter("username");

        String password =
                request.getParameter("password");

        LoginDAO dao =
                new LoginDAO();

        if(dao.validate(username,password)) {

            HttpSession session =
                    request.getSession();

            session.setAttribute(
                    "user",
                    username);

            response.sendRedirect(
                    "dashboard.jsp");

        } else {

            response.getWriter()
                    .println("Invalid Login");
        }
    }
}