<%@ page import="com.library.model.Book" %>

<%
if(session.getAttribute("user")==null){
    response.sendRedirect("login.html");
    return;
}

Book b =
(Book)request.getAttribute("book");
%>

<html>
<body>

<h2>Update Book</h2>

<form action="UpdateBookServlet"
      method="post">

Book ID:
<input type="text"
       name="bid"
       value="<%=b.getBid()%>"
       readonly>

<br><br>

Book Name:
<input type="text"
       name="bname"
       value="<%=b.getBname()%>">

<br><br>

Author:
<input type="text"
       name="author"
       value="<%=b.getAuthor()%>">

<br><br>

Price:
<input type="text"
       name="price"
       value="<%=b.getPrice()%>">

<br><br>

<input type="submit"
       value="Update Book">

</form>

</body>
</html>