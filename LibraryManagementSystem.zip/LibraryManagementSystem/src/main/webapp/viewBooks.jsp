<%@ page import="java.util.*" %>
<%@ page import="com.library.model.Book" %>

<%
if(session.getAttribute("user")==null){
    response.sendRedirect("login.html");
    return;
}
%>

<table border="1">

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Author</th>
    <th>Price</th>
    <th>Action</th>
</tr>

<%
List<Book> books =
(List<Book>)request.getAttribute("books");

for(Book b : books){
%>

<tr>

<td><%=b.getBid()%></td>

<td><%=b.getBname()%></td>

<td><%=b.getAuthor()%></td>

<td><%=b.getPrice()%></td>

<td>
<a href="EditBookServlet?bid=<%=b.getBid()%>">
Edit
</a>
</td>

</tr>

<%
}
%>

</table>

<br><br>

<a href="dashboard.jsp">
Back to Dashboard
</a>