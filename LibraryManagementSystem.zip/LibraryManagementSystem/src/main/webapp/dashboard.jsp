<%
String user =
(String)session.getAttribute("user");

if(user==null){
response.sendRedirect("login.html");
return;
}
%>

<h2>Welcome <%=user%></h2>

<a href="addBook.jsp">
Add Book
</a>

<br><br>

<a href="ViewBookServlet">
View Books
</a>

<br><br>

<a href="logout">
Logout
</a>