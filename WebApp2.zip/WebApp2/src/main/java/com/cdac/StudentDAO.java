package com.cdac;

import java.sql.*;
import java.util.*;

public class StudentDAO
{
    Connection con;

    public StudentDAO() throws Exception
    {
        Class.forName(
            "com.mysql.cj.jdbc.Driver");

        con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/cdac",
            "root",
            "cdacacts");
    }

    public int addStudent(Student s)
            throws Exception
    {
        PreparedStatement ps =
        con.prepareStatement(
        "insert into student values(?,?,?)");

        ps.setInt(1,s.getSid());
        ps.setString(2,s.getSname());
        ps.setString(3,s.getCourse());

        return ps.executeUpdate();
    }

    public ArrayList<Student> getStudents()
            throws Exception
    {
        ArrayList<Student> list =
                new ArrayList<>();

        Statement st =
                con.createStatement();

        ResultSet rs =
        st.executeQuery(
        "select * from student");

        while(rs.next())
        {
            Student s =
                    new Student();

            s.setSid(rs.getInt(1));
            s.setSname(rs.getString(2));
            s.setCourse(rs.getString(3));

            list.add(s);
        }

        return list;
    }
}

