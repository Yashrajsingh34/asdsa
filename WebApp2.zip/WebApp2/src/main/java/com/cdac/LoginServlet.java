package com.cdac;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws IOException
    {
        String uname = request.getParameter("uname");
        String pwd = request.getParameter("pwd");

        if("admin".equals(uname) && "123".equals(pwd))
        {
            HttpSession session = request.getSession();

            session.setAttribute("username", uname);

            response.sendRedirect("addstudent.html");
        }
        else
        {
            response.setContentType("text/html");

            response.getWriter().println("<h2>Invalid Login</h2>");
            response.getWriter().println("<a href='login.html'>Try Again</a>");
        }
    }
}