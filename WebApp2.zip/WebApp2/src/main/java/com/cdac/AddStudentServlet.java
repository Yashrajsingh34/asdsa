package com.cdac;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/add")
public class AddStudentServlet extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws IOException
    {
        response.setContentType("text/html");

        try
        {
            HttpSession session =
                    request.getSession(false);

            if(session == null)
            {
                response.sendRedirect("login.html");
                return;
            }

            Student s = new Student();

            s.setSid(
                Integer.parseInt(
                    request.getParameter("sid")));

            s.setSname(
                request.getParameter("sname"));

            s.setCourse(
                request.getParameter("course"));

            StudentDAO dao =
                    new StudentDAO();

            int n = dao.addStudent(s);

            if(n > 0)
            {
                response.getWriter().println(
                    "<h2>Student Added Successfully</h2>");

                response.getWriter().println(
                    "<a href='addstudent.html'>Add Another Student</a><br><br>");

                response.getWriter().println(
                    "<a href='view'>View Students</a>");
            }
            else
            {
                response.getWriter().println(
                    "<h2>Student Not Added</h2>");
            }
        }
        catch(Exception ex)
        {
            response.getWriter().println(
                "<h2>Error : " + ex.getMessage() + "</h2>");

            ex.printStackTrace();
        }
    }
}